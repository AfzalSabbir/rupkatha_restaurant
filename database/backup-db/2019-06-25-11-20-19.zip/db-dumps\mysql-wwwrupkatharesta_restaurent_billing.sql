
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admin_access_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_access_infos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_access_infos` WRITE;
/*!40000 ALTER TABLE `admin_access_infos` DISABLE KEYS */;
INSERT INTO `admin_access_infos` VALUES (1,1,'::1',NULL,'PC','Chrome',1,'2019-04-15 02:39:07','2019-04-15 02:39:07'),(2,1,'::1',NULL,'PC','Firefox',1,'2019-04-15 02:59:01','2019-04-15 02:59:01'),(3,1,'::1',NULL,'PC','Firefox',1,'2019-04-15 21:18:25','2019-04-15 21:18:25'),(4,1,'::1',NULL,'PC','Firefox',1,'2019-04-16 05:13:57','2019-04-16 05:13:57'),(5,1,'::1',NULL,'PC','Chrome',1,'2019-04-16 21:29:30','2019-04-16 21:29:30'),(6,1,'127.0.0.1',NULL,'PC','Firefox',1,'2019-04-17 21:10:33','2019-04-17 21:10:33'),(7,1,'::1',NULL,'PC','Firefox',1,'2019-04-18 02:15:15','2019-04-18 02:15:15'),(8,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 13:54:08','2019-04-18 13:54:08'),(9,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:09:37','2019-04-18 15:09:37'),(10,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:14:41','2019-04-18 15:14:41'),(11,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:17:54','2019-04-18 15:17:54'),(12,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:18:35','2019-04-18 15:18:35'),(13,1,'::1',NULL,'PC','Chrome',1,'2019-04-19 03:15:19','2019-04-19 03:15:19'),(14,1,'::1',NULL,'PC','Chrome',1,'2019-04-20 10:57:04','2019-04-20 10:57:04'),(15,1,'::1',NULL,'PC','Firefox',1,'2019-04-20 22:25:42','2019-04-20 22:25:42'),(16,1,'::1',NULL,'PC','Chrome',1,'2019-04-21 03:25:11','2019-04-21 03:25:11'),(17,1,'::1',NULL,'PC','Chrome',1,'2019-04-23 00:34:40','2019-04-23 00:34:40'),(18,1,'::1',NULL,'PC','Firefox',1,'2019-04-23 11:35:12','2019-04-23 11:35:12'),(19,2,'::1',NULL,'PC','Firefox',1,'2019-04-23 11:41:11','2019-04-23 11:41:11'),(20,1,'::1',NULL,'PC','Firefox',1,'2019-04-23 11:43:51','2019-04-23 11:43:51'),(21,1,'::1',NULL,'PC','Chrome',1,'2019-04-23 12:27:19','2019-04-23 12:27:19'),(22,1,'::1',NULL,'PC','Firefox',1,'2019-04-24 04:02:21','2019-04-24 04:02:21'),(23,1,'::1',NULL,'PC','Firefox',1,'2019-04-24 04:15:16','2019-04-24 04:15:16'),(24,1,'::1',NULL,'PC','Firefox',1,'2019-04-24 05:11:48','2019-04-24 05:11:48'),(25,1,'::1',NULL,'PC','Firefox',1,'2019-04-24 11:46:49','2019-04-24 11:46:49'),(26,1,'::1',NULL,'PC','Chrome',1,'2019-06-18 04:32:03','2019-06-18 04:32:03'),(27,1,'::1',NULL,'PC','Chrome',1,'2019-06-19 03:35:38','2019-06-19 03:35:38'),(28,1,'::1',NULL,'PC','Chrome',1,'2019-06-19 10:00:15','2019-06-19 10:00:15'),(29,1,'::1',NULL,'PC','Chrome',1,'2019-06-19 10:07:35','2019-06-19 10:07:35'),(30,3,'::1',NULL,'PC','Chrome',1,'2019-06-19 10:10:14','2019-06-19 10:10:14'),(31,1,'::1',NULL,'PC','Chrome',1,'2019-06-19 10:11:27','2019-06-19 10:11:27'),(32,1,'::1',NULL,'PC','Chrome',1,'2019-06-20 08:01:40','2019-06-20 08:01:40'),(33,1,'::1',NULL,'PC','Chrome',1,'2019-06-22 03:40:16','2019-06-22 03:40:16'),(34,1,'::1',NULL,'PC','Chrome',1,'2019-06-22 04:36:44','2019-06-22 04:36:44'),(35,1,'::1',NULL,'PC','Chrome',1,'2019-06-22 04:37:06','2019-06-22 04:37:06'),(36,1,'192.168.0.104',NULL,'PC','Chrome',1,'2019-06-23 12:05:41','2019-06-23 12:05:41'),(37,1,'::1',NULL,'PC','Chrome',1,'2019-06-24 04:14:51','2019-06-24 04:14:51'),(38,1,'::1',NULL,'PC','Chrome',1,'2019-06-24 12:21:46','2019-06-24 12:21:46'),(39,1,'::1',NULL,'PC','Chrome',1,'2019-06-25 05:01:29','2019-06-25 05:01:29');
/*!40000 ALTER TABLE `admin_access_infos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_role` tinyint(4) DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `admins_email_unique` (`email`) USING BTREE,
  UNIQUE KEY `admins_username_unique` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'Super Admin','super@gmail.com','superadmin',1,'public/images/admins/1556106587.png','$2y$10$tQVwD5VequDrZsgg5NUaHexmp3fGf.XI7zylpDEqSxf9WJITYiRWO',1,'ecOE7JRIxFyQ8QuFdxtk13lFY1AjrJNSyKIJOnK18V0BGkVdMNpwy9m6ZDXj','2019-03-24 12:00:00','2019-04-24 11:49:48'),(2,'Admin','admin@gmail.com','admin',2,NULL,'$2y$10$tQVwD5VequDrZsgg5NUaHexmp3fGf.XI7zylpDEqSxf9WJITYiRWO',1,'gV02AWVRulaSdFKJqqwcgB8964FxjAKuVn6uP0s9QbuHG0K1hZWeNm2W6pdg','2019-03-24 12:00:00','2019-04-15 03:51:44'),(3,'Test','jovoqiqo@mailinator.com','user1',3,'public/images/admins/1560938846.png','$2y$10$R0gWogAA5cujmNQL5mgcReRlz/jx1uewTWrHsH2shMdADqz2hr/nq',1,NULL,'2019-06-19 10:07:26','2019-06-19 10:07:26');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `sub_category_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `brands_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `categories_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Dolor sapiente sint','dolor-sapiente-sint','public/images/category/1560915627.png',1,'2019-06-19 03:40:28','2019-06-19 03:40:28');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cost_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cost_fields_title_unique` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cost_fields` WRITE;
/*!40000 ALTER TABLE `cost_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `cost_fields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `costs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'General',
  `cost_field_id` int(10) unsigned DEFAULT NULL,
  `cost_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Other',
  `pickdate` date NOT NULL,
  `quantity` double(8,2) DEFAULT '1.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `costs` WRITE;
/*!40000 ALTER TABLE `costs` DISABLE KEYS */;
/*!40000 ALTER TABLE `costs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_bn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `menu_position` int(10) unsigned DEFAULT NULL COMMENT '0 - Left | 1 - Top | 2 - Dropdown',
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Admin Settings','এডমিন সেটিংস',NULL,0,'fa fa-cogs',NULL,NULL,500,0,'2019-03-25 04:40:17','2019-04-23 10:57:50'),(2,'Change Password','পাসওয়ার্ড পরিবর্তন',1,0,'fa fa-cog','/admin/change-password','admin.password.form',1,0,'2019-03-25 04:42:35','2019-04-23 10:56:21'),(3,'Menu Permission','মেনু পারমিশন',NULL,0,'fa fa-diamond','/admin/role','admin.role.index',499,1,'2019-03-25 04:44:32','2019-06-18 10:10:45'),(4,'Log Activity','লগ এক্টিভিটি',NULL,0,'fa fa-history','/admin/log','admin.log.index',500,1,'2019-03-25 04:46:37','2019-06-18 10:11:33'),(5,'Assign','অনুমতি প্রদান',108,1,'fa fa-pencil','/admin/role/assign','admin.role.assign',1,1,'2019-03-25 04:48:50','2019-04-23 00:10:19'),(6,'Dashboard','ড্যাশবোর্ড',NULL,0,'fa fa-dashboard','/admin','admin.home',1,1,'2019-03-25 05:02:05','2019-03-25 05:02:05'),(33,'Product','পণ্য',NULL,0,'fa fa-archive',NULL,NULL,50,1,'2019-03-29 21:43:47','2019-03-29 22:43:46'),(34,'Product List','পণ্য তালিকা',33,0,'fa fa-list-ul','/admin/product','admin.product.index',2,1,'2019-03-29 21:45:03','2019-04-21 00:07:45'),(35,'Add New','নতুন যোগ করুন',33,0,'fa fa-plus','/admin/product/add','admin.product.create',1,1,'2019-03-29 21:47:44','2019-04-21 00:07:42'),(36,'Edit','এডিট',34,1,'fa fa-pencil',NULL,'admin.product.edit',2,1,'2019-03-29 21:48:20','2019-04-05 23:27:38'),(37,'Delete','ডিলিট',34,1,'fa fa-trash',NULL,'admin.product.delete',3,1,'2019-03-29 21:49:55','2019-04-05 23:27:26'),(38,'Category','ক্যাটাগরি',NULL,0,'fa fa-pie-chart',NULL,NULL,90,1,'2019-03-29 21:51:15','2019-03-30 00:11:55'),(39,'Category List','ক্যাটাগরি তালিকা',38,0,'fa fa-list-ul','/admin/category','admin.category.index',2,1,'2019-03-29 21:51:59','2019-04-21 00:08:34'),(40,'Add New','নতুন যোগ করুন',38,0,'fa fa-plus','/admin/category/add','admin.category.create',1,1,'2019-03-29 21:52:31','2019-04-21 00:08:29'),(41,'Edit','এডিট',39,1,'fa fa-pencil',NULL,'admin.category.edit',1,1,'2019-03-29 21:53:02','2019-03-29 22:55:28'),(42,'Delete','ডিলিট',39,1,'fa fa-trash',NULL,'admin.category.delete',2,1,'2019-03-29 21:53:33','2019-03-29 23:01:25'),(82,'Site Settings','সাইট সেটিংস',NULL,0,'fa fa-sliders','/admin/setting','admin.setting.index',450,1,'2019-04-10 22:30:44','2019-04-11 02:33:10'),(88,'Sale','বিক্রয়',NULL,0,'fa fa-money',NULL,NULL,2,1,'2019-04-15 21:53:59','2019-04-15 21:53:59'),(89,'All Sale','সকল বিক্রয়',88,0,'fa fa-list-ul','/admin/sale','admin.sale.index',2,1,'2019-04-15 22:03:48','2019-04-21 00:02:07'),(90,'New Sale','নতুন বিক্রয়',88,0,'fa fa-plus','/admin/sale/add','admin.sale.add',1,1,'2019-04-15 22:04:42','2019-04-21 00:02:10'),(91,'Edit','ইডিট',89,1,'fa fa-edit',NULL,'admin.sale.edit',2,1,'2019-04-15 22:05:33','2019-04-15 22:05:33'),(92,'Delete','ডিলিট',89,1,'fa fa-trash',NULL,'admin.sale.delete',3,1,'2019-04-15 22:06:43','2019-04-15 22:06:43'),(93,'View','ভিউ',89,1,'fa fa-eye',NULL,'admin.sale.view',1,1,'2019-04-16 04:13:15','2019-04-16 04:13:15'),(94,'Cost','খরচ',NULL,0,'fa fa-contao',NULL,NULL,100,1,'2019-04-17 00:05:39','2019-04-20 22:26:08'),(95,'Cost List','খরচ তালিকা',94,0,'fa fa-list-ul','/admin/cost','admin.cost.index',2,1,'2019-04-17 00:29:35','2019-04-17 00:29:35'),(96,'Add New','নতুন যোগ করুন',94,0,'fa fa-plus','/admin/cost/add','admin.cost.add',1,1,'2019-04-17 00:30:27','2019-04-17 00:30:27'),(97,'Edit','এডিট',95,1,'fa fa-edit',NULL,'admin.cost.edit',1,1,'2019-04-17 00:31:30','2019-04-17 00:31:30'),(98,'Delete','ডিলিট',95,1,'fa fa-trash',NULL,'admin.cost.delete',2,1,'2019-04-17 00:33:15','2019-04-17 00:33:15'),(99,'view','দেখা',34,1,'fa fa-eye',NULL,'admin.product.view',1,1,'2019-04-18 04:15:38','2019-04-18 04:15:38'),(100,'Backup','ব্যাকআপ',NULL,0,'fa fa-database','/admin/backup','admin.backup.index',999,1,'2019-04-19 03:49:55','2019-06-18 10:11:45'),(101,'Action','কার্যক্রম',100,0,'fa fa-home','/admin/backup','admin.backup.index',1,1,'2019-04-19 03:51:23','2019-04-19 03:54:34'),(102,'Download','ডাউনলোড',101,1,'fa fa-download',NULL,'admin.backup.index',1,1,'2019-04-19 03:52:24','2019-04-19 03:52:24'),(103,'Delete','ডিলিট',101,1,'fa fa-trash',NULL,'admin.backup.index',2,1,'2019-04-19 03:52:58','2019-04-19 03:52:58'),(104,'Cost Field','খরচ ক্ষেত্র',94,0,'fa fa-contao','/admin/cost_field','admin.cost_field.index',0,1,'2019-04-20 22:10:13','2019-04-23 00:03:15'),(106,'Edit','এডিট',104,1,'fa fa-pencil',NULL,'admin.cost_field.edit',1,1,'2019-04-20 22:12:17','2019-04-23 00:04:37'),(107,'Delete','ডিলিট',104,1,'fa fa-trash',NULL,'admin.cost_field.delete',2,1,'2019-04-20 22:13:04','2019-04-23 00:04:46'),(108,'Action','একশন',3,0,'fa fa-edit','/admin/role','admin.role.index',1,1,'2019-04-23 00:09:44','2019-04-23 00:11:56'),(109,'Balance Sheet','ব্যালেন্স শীট',NULL,0,'fa fa-money','/admin/balance_sheet','admin.balance_sheet.index',150,1,'2019-04-23 01:03:14','2019-04-23 01:03:14'),(111,'Purchase','পার্চেস',NULL,0,'fa fa-sitemap',NULL,NULL,110,1,'2019-06-18 05:22:06','2019-06-18 08:30:39'),(112,'Add Item','আইটেম যোগ করুন',111,0,'fa fa-plus','admin/purchase/purchase_item/add','admin.purchase_item.add',3,1,'2019-06-18 05:22:06','2019-06-18 08:29:40'),(113,'Item List','আইটেম তালিকা',111,0,'fa fa-list-ul','admin/purchase/purchase_item','admin.purchase_item.index',4,1,'2019-06-18 05:22:06','2019-06-18 08:29:36'),(114,'Edit','এডিট',113,1,'fa fa-pencil','','admin.purchase_item.edit',1,1,'2019-06-18 05:22:06','2019-06-18 05:22:06'),(115,'Delete','ডিলিট',113,1,'fa fa-trash','','admin.purchase_item.delete',2,1,'2019-06-18 05:22:06','2019-06-18 05:22:06'),(116,'Add Purchase','পার্চেস যোগ করুন',111,0,'fa fa-dollar','/admin/purchase/add','admin.purchase.add',1,1,'2019-06-18 05:33:36','2019-06-18 08:31:04'),(117,'Purchase History','পার্চেস হিস্টরি',111,0,'fa fa-history','/admin/purchase','admin.purchase.index',2,1,'2019-06-18 08:27:34','2019-06-18 08:27:34'),(118,'Edit','এডিট',117,1,'fa fa-pencil','/admin/purchase/edit','admin.purchase.edit',1,1,'2019-06-18 09:13:12','2019-06-18 09:13:12'),(119,'Delete','ডিলিট',117,1,'fa fa-trash','/admin/purchase/delete','admin.purchase.delete',2,1,'2019-06-18 09:13:45','2019-06-18 09:13:45');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2018_03_26_200821_create_admins_table',1),(2,'2019_03_04_084037_create_menus_table',1),(3,'2019_03_05_074453_create_roles_table',1),(4,'2019_03_06_090310_create_admin_access_infos_table',1),(5,'2019_03_25_140140_create_units_table',1),(6,'2019_03_25_140157_create_categories_table',1),(7,'2019_03_25_140207_create_sub_categories_table',1),(8,'2019_03_25_140231_create_brands_table',1),(9,'2019_03_25_140240_create_password_resets_table',1),(10,'2019_03_25_140240_create_users_table',1),(11,'2019_04_10_152516_create_settings_table',1),(12,'2019_04_15_081819_create_products_table',1),(13,'2019_04_15_082535_create_sales_table',1),(14,'2019_04_15_082553_create_sale_products_table',1),(15,'2019_04_15_083217_create_costs_table',1),(16,'2019_04_21_043538_create_cost_fields_table',2),(17,'2019_06_18_111635_create_purchase_items_table',3),(18,'2019_06_18_111935_create_purchase_histories_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regular_sale_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_sale` int(10) unsigned DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `products_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Neque nostrud nihil','neque-nostrud-nihil',1,'Tenetur quidem volup','public/images/products/1560915571.png','362','646','63',0,1,'2019-06-19 03:39:32','2019-06-19 03:39:32'),(2,'Officiis delectus e','officiis-delectus-e',1,'Voluptas sunt dolor','public/images/products/1560915643.png','857','100','0',0,1,'2019-06-19 03:40:43','2019-06-19 03:40:43'),(3,'In nihil non omnis a','in-nihil-non-omnis-a',1,'Eos rem accusantium','public/images/products/1560915667.png','66','831','70',0,1,'2019-06-19 03:41:07','2019-06-19 03:41:07'),(4,'ewrwerwer','ewrwerwer',1,'werwerwer','public/images/products/1560915800.png','1000','9000','0',0,1,'2019-06-19 03:43:20','2019-06-19 03:43:20');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_item_id` int(11) NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_histories` WRITE;
/*!40000 ALTER TABLE `purchase_histories` DISABLE KEYS */;
INSERT INTO `purchase_histories` VALUES (1,2,'2','2',NULL,'2019-06-18',NULL,9,'2019-06-18 11:36:49','2019-06-18 11:41:04'),(2,1,'1','1',NULL,'2019-06-18',NULL,9,'2019-06-18 11:36:49','2019-06-18 11:41:08'),(3,3,'100','30',NULL,'2019-06-18',NULL,1,'2019-06-18 11:40:27','2019-06-18 11:40:27'),(4,2,'200','20',NULL,'2019-06-18',NULL,1,'2019-06-18 11:40:27','2019-06-18 11:40:27'),(5,1,'300','10',NULL,'2019-06-18',NULL,1,'2019-06-18 11:40:27','2019-06-18 11:40:27');
/*!40000 ALTER TABLE `purchase_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `regular_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_items` WRITE;
/*!40000 ALTER TABLE `purchase_items` DISABLE KEYS */;
INSERT INTO `purchase_items` VALUES (1,'Ullam non doloribus','652','Facere quia quidem d',1,'2019-06-18 11:10:57','2019-06-18 11:10:57'),(2,'Omnis sunt aliquam q','878','Quia nulla praesenti',1,'2019-06-18 11:11:03','2019-06-18 11:11:03'),(3,'Dolor voluptatem ea','124','Voluptatibus vitae c',1,'2019-06-18 11:11:13','2019-06-18 11:11:13');
/*!40000 ALTER TABLE `purchase_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_menu` text COLLATE utf8mb4_unicode_ci,
  `in_body` text COLLATE utf8mb4_unicode_ci,
  `role` tinyint(3) unsigned NOT NULL,
  `admin_id` int(10) DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'[\"6\",\"88\",\"33\",\"38\",\"94\",\"111\",\"109\",\"82\",\"3\",\"4\",\"100\"]','[\"104\",\"101\",\"40\",\"108\",\"35\",\"116\",\"39\",\"34\",\"96\",\"95\",\"90\",\"89\",\"117\",\"113\",\"112\"]','[\"93\",\"102\",\"103\",\"92\",\"114\",\"5\",\"37\",\"119\",\"91\",\"118\",\"36\",\"97\",\"42\",\"106\",\"107\",\"41\",\"98\",\"99\",\"115\"]',1,1,1,'2019-04-15 03:12:29','2019-06-18 09:15:17'),(2,'[\"6\"]','null',NULL,3,3,1,'2019-06-19 10:09:42','2019-06-19 10:09:42');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sale_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '1.00',
  `price` double(8,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sale_products` WRITE;
/*!40000 ALTER TABLE `sale_products` DISABLE KEYS */;
INSERT INTO `sale_products` VALUES (15,13,2,2.00,100.00,1,NULL,NULL),(16,13,1,1.00,239.02,1,NULL,NULL),(17,14,2,1.00,100.00,1,NULL,NULL),(18,14,1,1.00,239.02,1,NULL,NULL),(19,14,3,2.00,249.30,1,NULL,NULL),(20,15,1,1.00,239.02,1,NULL,NULL),(21,15,2,1.00,100.00,1,NULL,NULL),(22,15,3,1.00,249.30,1,NULL,NULL),(23,16,3,1.00,249.30,1,NULL,NULL),(24,17,3,1.00,249.30,1,NULL,NULL),(25,18,2,1.52,100.00,1,NULL,NULL),(26,19,2,1.00,100.00,1,NULL,NULL),(27,20,3,1.00,249.30,1,NULL,NULL),(28,21,1,1.50,239.02,1,NULL,NULL);
/*!40000 ALTER TABLE `sale_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` float(10,2) DEFAULT '0.00' COMMENT 'in TK',
  `discount_2` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'in %',
  `vat` float(10,2) DEFAULT '0.00',
  `total_price_after_discount` float(10,2) DEFAULT NULL,
  `total_product` double(8,2) NOT NULL,
  `given_money` double(8,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (13,1,NULL,NULL,'439.02',4.00,0.00,15.00,500.87,3.00,510.00,1,'2019-06-22 05:06:47','2019-06-22 05:06:47'),(14,1,NULL,NULL,'837.62',0.00,0.00,15.00,963.26,4.00,1000.00,1,'2019-06-22 06:12:33','2019-06-22 06:12:33'),(15,1,NULL,NULL,'588.32',0.00,0.00,15.00,676.57,3.00,1000.00,1,'2019-06-22 06:19:29','2019-06-22 06:19:29'),(16,1,NULL,NULL,'249.30',0.00,0.00,15.00,286.69,1.00,300.00,1,'2019-06-22 06:22:42','2019-06-22 06:22:42'),(17,1,NULL,NULL,'249.30',0.00,0.00,0.00,249.30,1.00,300.00,1,'2019-06-24 04:53:02','2019-06-24 04:53:02'),(18,1,NULL,NULL,'151.52',51.00,0.00,15.00,100.52,1.52,200.00,1,'2019-06-24 06:01:09','2019-06-24 06:01:09'),(19,1,NULL,NULL,'100.00',0.00,0.00,0.00,100.00,1.00,100.00,1,'2019-06-24 06:02:59','2019-06-24 06:02:59'),(20,1,NULL,NULL,'249.30',49.00,10.00,10.00,200.30,1.00,201.00,1,'2019-06-24 06:03:30','2019-06-24 06:03:30'),(21,1,NULL,NULL,'358.53',58.00,10.00,10.00,300.53,1.50,500.00,1,'2019-06-24 06:14:20','2019-06-24 06:14:20');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `youtube` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'logo-1555583380.jpg','favicon-1555584605.jpg','Restaurent Bill','superadmin@Restaurent-Bill.com','01234567890','facebook','twitter','youtube','linkedin','City: Mymensingh\r\nCountry: Bangladesh\r\nState: Mymensingh Division\r\nZipcode: 2200','1','2019-04-10 12:00:00','2019-06-18 09:59:59');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `sub_categories_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_role` tinyint(4) DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` int(10) unsigned DEFAULT NULL,
  `upazilla_id` int(10) unsigned DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `users_email_unique` (`email`) USING BTREE,
  UNIQUE KEY `users_mobile_unique` (`mobile`) USING BTREE,
  UNIQUE KEY `users_username_unique` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

